const products = [
  { id:1, name:"African Handicraft", price:50 },
  { id:2, name:"Organic Shea Butter", price:30 },
  { id:3, name:"Coffee Beans", price:20 },
];
const productList = document.getElementById('product-list');
products.forEach(p => {
  const div = document.createElement('div');
  div.className = 'product';
  div.innerHTML = `<h3>${p.name}</h3><p>Price: $${p.price}</p>`;
  productList.appendChild(div);
});